﻿import pandas as pd

def compile_production_dublin_core_matrix():
    print("⏳ Running Production Extraction Utility & Metadata Flattener...")
    try:
        # Load your zero-defect spreadsheet output from the Week 3 repair engine
        df = pd.read_csv("omeka_s_flattened_upload.csv", dtype=str)
    except FileNotFoundError:
        print("❌ Error: omeka_s_flattened_upload.csv not found. Please complete Week 3 pipelines first.")
        return

    # Crosswalk ISAD(G) variables cleanly into standard flat Dublin Core structural keys
    dc_matrix = pd.DataFrame()
    dc_matrix['dcterms:identifier'] = df['reference_code']
    dc_matrix['dcterms:type'] = df['level']
    dc_matrix['dcterms:title'] = df['title']
    dc_matrix['dcterms:date'] = df['date']
    dc_matrix['dcterms:creator'] = df['creator'].fillna('Unassigned / System Inherited')
    dc_matrix['dcterms:format'] = df['extent']
    dc_matrix['dcterms:description'] = df['scope_and_content']

    # Save out your finalized production batch spreadsheet payload
    output_filename = "final_production_dublin_core_upload.csv"
    dc_matrix.to_csv(output_filename, index=False, encoding='utf-8')
    print(f"🎉 Success! Dublin Core compilation complete. File saved to: '{output_filename}'")

if __name__ == '__main__':
    compile_production_dublin_core_matrix()
